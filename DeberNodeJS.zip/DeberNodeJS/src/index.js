const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();

//const req = require('express/lib/request');
//const res = require('express/lib/response');



const app = express();
const port = process.env.PORT || 9000;


app.get('/', (req, res)=>{
    res.send("Bienvenidos a mi Api")
});


//mongoose.connect(process.env.MONGODB_URI).then(() => console.log("Conected to MongoDB Atlas")).catch((error) => console.error(error));
mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => console.log('Conectado a MongoDB Atlas'))
  .catch((error) => console.error(error));
app.listen(port, () => console.log('Servidor  escuchando al puerto', port));

